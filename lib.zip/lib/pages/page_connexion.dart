import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import '../constants/app_colors.dart';
import '../models/user.dart';
import '../services/data_provider_service.dart';
import '../services/offline_service.dart';
import '../services/error_reporting_service.dart';
import '../services/google_auth_service.dart';
import 'page_inscription.dart';

import 'page_onboarding.dart';
import 'page_forgot_password.dart';
import 'page_phone_otp.dart';
import 'page_tasks.dart';

class PageConnexion extends StatefulWidget {
  const PageConnexion({super.key});

  @override
  State<PageConnexion> createState() => _PageConnexionState();
}

class _PageConnexionState extends State<PageConnexion> {
  // ── Controllers ──
  final _emailCtrl    = TextEditingController();
  final _phoneCtrl    = TextEditingController();
  final _passwordCtrl = TextEditingController();

  // ── State ──
  bool _useEmail       = true;   // Email/Phone tab
  bool _obscurePassword = true;
  bool _rememberMe     = false;
  bool _isButtonEnabled = false;
  bool _isLoading      = false;
  String? _emailError;

  @override
  void initState() {
    super.initState();
    _emailCtrl.addListener(_validate);
    _phoneCtrl.addListener(_validate);
    _passwordCtrl.addListener(_validate);
  }

  void _validate() {
    bool loginOk;
    if (_useEmail) {
      loginOk = RegExp(r'^[\w\-\.]+@([\w\-]+\.)+[\w\-]{2,4}$')
          .hasMatch(_emailCtrl.text.trim());
    } else {
      loginOk = _phoneCtrl.text.trim().length >= 8;
    }
    
    setState(() {
      // Email validation error message
      if (_useEmail && _emailCtrl.text.isNotEmpty && !loginOk) {
        _emailError = 'Format d\'email invalide';
      } else {
        _emailError = null;
      }
      
      _isButtonEnabled = loginOk && (_useEmail ? _passwordCtrl.text.length >= 8 : true);
    });
  }

  @override
  void dispose() {
    _emailCtrl.dispose();
    _phoneCtrl.dispose();
    _passwordCtrl.dispose();
    super.dispose();
  }

  // ── Login logic ──────────────────────────────────────────────────────────────
  Future<void> _onLogin() async {
    setState(() => _isLoading = true);
    try {
      final loginVal = _useEmail
          ? _emailCtrl.text.trim()
          : _phoneCtrl.text.trim();

      if (_useEmail) {
        // Email login with offline support
        try {
          // First try to find user in remote providers
          User? user = await DataProviderService.findUser(loginVal);
          
          if (user != null) {
            // User found in remote providers
            await ErrorReportingService.reportMessage('User logged in: ${user.email}');
            _showSnack('Bienvenue ${user.fullname} 👋');
            await Future.delayed(const Duration(milliseconds: 800));
            
            if (!mounted) return;
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(builder: (_) => PageTasks(user: user!)),
            );
            return;
          } else {
            // Try to find in offline storage
            user = await OfflineService.findOfflineUser(loginVal);
            
            if (user != null) {
              await ErrorReportingService.reportMessage('User logged in offline: ${user.email}');
              _showSnack('Bienvenue ${user.fullname} 👋 (Mode hors ligne)');
              await Future.delayed(const Duration(milliseconds: 800));
              
              if (!mounted) return;
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (_) => PageTasks(user: user!)),
              );
              return;
            } else {
              _showSnack('Email non trouvé', isError: true);
            }
          }
        } catch (e) {
          await ErrorReportingService.reportError(
            e, 
            StackTrace.current, 
            context: {
              'action': 'login',
              'email': loginVal,
            }
          );
          _showSnack('Erreur de connexion : $e', isError: true);
        }
      } else {
        // Phone login - Redirection vers OTP
        String formattedPhone = loginVal;
        if (!loginVal.startsWith('+')) {
          formattedPhone = '+221$loginVal'; // Ajouter l'indicatif sénégalais par défaut
        }
        
        if (!mounted) return;
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => PagePhoneOTP(phoneNumber: formattedPhone),
          ),
        );
        return;
      }
    } catch (e) {
      await ErrorReportingService.reportError(
        e, 
        StackTrace.current, 
        context: {
          'action': 'login_general',
          'login_val': _useEmail ? _emailCtrl.text.trim() : _phoneCtrl.text.trim(),
        }
      );
      _showSnack('Erreur de connexion : $e', isError: true);
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  void _showSnack(String msg, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg),
      backgroundColor: isError ? Colors.red[400] : Colors.green[600],
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
    ));
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 16),

              // ── Back button ──
              Row(
                children: [
                  IconButton(
                    onPressed: () => Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(builder: (_) => const PageOnboarding()),
                    ),
                    icon: const Icon(
                      Icons.arrow_back_rounded,
                      color: AppColors.textDark,
                      size: 24,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),

              // ── Title ──
              const Center(
                child: Text(
                  'Login',
                  style: TextStyle(
                    fontSize: 30,
                    fontWeight: FontWeight.bold,
                    color: AppColors.textDark,
                  ),
                ),
              ),
              const SizedBox(height: 6),
              const Center(
                child: Text(
                  'Please provide the details below to log in',
                  style: TextStyle(fontSize: 13, color: AppColors.textGrey),
                  textAlign: TextAlign.center,
                ),
              ),
              const SizedBox(height: 28),

              // ── Email / Phone toggle ──
              Container(
                height: 48,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: AppColors.inputBorder),
                ),
                child: Row(
                  children: [
                    _TabButton(
                      label: 'Email',
                      isActive: _useEmail,
                      onTap: () {
                        setState(() => _useEmail = true);
                        _validate();
                      },
                    ),
                    _TabButton(
                      label: 'Phone',
                      isActive: !_useEmail,
                      onTap: () {
                        setState(() => _useEmail = false);
                        _validate();
                      },
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),

              // ── Input field ──
              if (_useEmail)
                _InputField(
                  controller: _emailCtrl,
                  hint: 'Enter Your Email',
                  prefixIcon: Icons.mail_outline_rounded,
                  keyboardType: TextInputType.emailAddress,
                  errorText: _emailError,
                )
              else
                _InputField(
                  controller: _phoneCtrl,
                  hint: 'Enter Your Phone',
                  prefixIcon: Icons.phone_outlined,
                  keyboardType: TextInputType.phone,
                ),
              const SizedBox(height: 14),

              // ── Password (uniquement pour email) ──
              if (_useEmail) ...[
                _InputField(
                  controller: _passwordCtrl,
                  hint: 'Enter Your Password',
                  prefixIcon: Icons.lock_outline_rounded,
                  obscure: _obscurePassword,
                  suffixIcon: IconButton(
                    icon: Icon(
                      _obscurePassword
                          ? Icons.visibility_off_outlined
                          : Icons.visibility_outlined,
                      color: AppColors.textGrey,
                      size: 20,
                    ),
                    onPressed: () =>
                        setState(() => _obscurePassword = !_obscurePassword),
                  ),
                ),
                const SizedBox(height: 14),
              ],

              // ── Remember me + Forget password (uniquement pour email) ──
              if (_useEmail) ...[
                Row(
                  children: [
                    SizedBox(
                      width: 20,
                      height: 20,
                      child: Checkbox(
                        value: _rememberMe,
                        activeColor: AppColors.primary,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(4)),
                        onChanged: (v) =>
                            setState(() => _rememberMe = v ?? false),
                      ),
                    ),
                    const SizedBox(width: 8),
                    const Text('Remember me',
                        style: TextStyle(
                            color: AppColors.textGrey, fontSize: 13)),
                    const Spacer(),
                    GestureDetector(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (_) => const PageForgotPassword()),
                        );
                      },
                      child: const Text(
                        'Forget Password?',
                        style: TextStyle(
                          color: AppColors.primary,
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 28),
              ],

              // ── Log In button ──
              SizedBox(
                width: double.infinity,
                height: 52,
                child: ElevatedButton(
                  onPressed: _isButtonEnabled && !_isLoading ? _onLogin : null,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.primary,
                    disabledBackgroundColor:
                        AppColors.primary.withValues(alpha: 0.5),
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12)),
                    elevation: 0,
                  ),
                  child: _isLoading
                      ? const SizedBox(
                          width: 22,
                          height: 22,
                          child: CircularProgressIndicator(
                              color: Colors.white, strokeWidth: 2.5))
                      : const Text(
                          'Log In',
                          style: TextStyle(
                              fontSize: 16, fontWeight: FontWeight.w600),
                        ),
                ),
              ),
              const SizedBox(height: 24),

              // ── Or Continue With ──
              Row(
                children: [
                  const Expanded(
                      child: Divider(color: AppColors.inputBorder)),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    child: Text(
                      'Or Continue With',
                      style: TextStyle(
                          color: AppColors.textGrey.withValues(alpha: 0.8),
                          fontSize: 12),
                    ),
                  ),
                  const Expanded(
                      child: Divider(color: AppColors.inputBorder)),
                ],
              ),
              const SizedBox(height: 20),

              // ── Social buttons ──
              Row(
                children: [
                  Expanded(
                    child: _SocialButton(
                      label: 'Google',
                      svgAsset: 'assets/google_logo.svg',
                      onTap: () async {
                        try {
                          setState(() => _isLoading = true);
                          
                          final user = await GoogleAuthService.signInWithGoogle();
                          
                          if (user != null) {
                            _showSnack('Bienvenue ${user.fullname} 👋');
                            await Future.delayed(const Duration(milliseconds: 800));
                            
                            if (!mounted) return;
                            Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(builder: (_) => PageTasks(user: user)),
                            );
                          }
                        } catch (e) {
                          _showSnack('Erreur de connexion Google: $e', isError: true);
                        } finally {
                          if (mounted) setState(() => _isLoading = false);
                        }
                      },
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: _SocialButton(
                      label: 'Apple',
                      svgAsset: 'assets/apple_logo.svg',
                      onTap: () {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            content: Text('Connexion Apple bientôt disponible'),
                            backgroundColor: Colors.grey,
                          ),
                        );
                      },
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 28),

              // ── Sign up link ──
              Center(
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Text("Don't have an account? ",
                        style: TextStyle(
                            color: AppColors.textGrey, fontSize: 13)),
                    GestureDetector(
                      onTap: () => Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(
                            builder: (_) => const PageInscription()),
                      ),
                      child: const Text(
                        'Sign up',
                        style: TextStyle(
                          color: AppColors.primary,
                          fontSize: 13,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ─── Reusable widgets ─────────────────────────────────────────────────────────

class _TabButton extends StatelessWidget {
  final String label;
  final bool isActive;
  final VoidCallback onTap;

  const _TabButton({
    required this.label,
    required this.isActive,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          margin: const EdgeInsets.all(4),
          decoration: BoxDecoration(
            color: isActive ? AppColors.primary : Colors.transparent,
            borderRadius: BorderRadius.circular(9),
          ),
          child: Center(
            child: Text(
              label,
              style: TextStyle(
                color: isActive ? Colors.white : AppColors.textGrey,
                fontWeight:
                    isActive ? FontWeight.w600 : FontWeight.normal,
                fontSize: 14,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _InputField extends StatelessWidget {
  final TextEditingController controller;
  final String hint;
  final IconData prefixIcon;
  final TextInputType keyboardType;
  final bool obscure;
  final Widget? suffixIcon;
  final String? errorText;

  const _InputField({
    required this.controller,
    required this.hint,
    required this.prefixIcon,
    this.keyboardType = TextInputType.text,
    this.obscure = false,
    this.suffixIcon,
    this.errorText,
  });

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: controller,
      keyboardType: keyboardType,
      obscureText: obscure,
      style: const TextStyle(
          fontSize: 14, color: AppColors.textDark),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle:
            const TextStyle(color: AppColors.textGrey, fontSize: 14),
        prefixIcon: Icon(prefixIcon,
            color: AppColors.textGrey, size: 20),
        suffixIcon: suffixIcon,
        errorText: errorText,
        errorStyle: const TextStyle(fontSize: 12, color: Colors.red),
        filled: true,
        fillColor: Colors.white,
        contentPadding: const EdgeInsets.symmetric(
            horizontal: 16, vertical: 14),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide:
              const BorderSide(color: AppColors.inputBorder),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide:
              const BorderSide(color: AppColors.inputBorder),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide:
              const BorderSide(color: AppColors.primary, width: 1.5),
        ),
      ),
    );
  }
}

class _SocialButton extends StatelessWidget {
  final String label;
  final String svgAsset;
  final VoidCallback onTap;

  const _SocialButton({
    required this.label,
    required this.svgAsset,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 50,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: AppColors.inputBorder),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SvgPicture.asset(
              svgAsset,
              width: 20,
              height: 20,
            ),
            const SizedBox(width: 8),
            Text(
              label,
              style: const TextStyle(
                fontWeight: FontWeight.w600,
                fontSize: 14,
                color: AppColors.textDark,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
