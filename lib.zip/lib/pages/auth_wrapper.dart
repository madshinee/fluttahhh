import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'page_onboarding.dart';
import 'page_reset_password.dart';
import 'page_connexion.dart';
import '../services/storage_service.dart';

class AuthWrapper extends StatefulWidget {
  const AuthWrapper({super.key});

  @override
  State<AuthWrapper> createState() => _AuthWrapperState();
}

class _AuthWrapperState extends State<AuthWrapper> {
  bool _isInitialized = false;
  bool _showOnboarding = true;

  @override
  void initState() {
    super.initState();
    _initializeApp();
    _handlePasswordResetLink();
  }

  Future<void> _initializeApp() async {
    await StorageService.init();
    final shouldShowOnboarding = await _shouldShowOnboarding();
    
    setState(() {
      _showOnboarding = shouldShowOnboarding;
      _isInitialized = true;
    });
  }

  Future<bool> _shouldShowOnboarding() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      
      // Check if it's the first launch
      final firstLaunch = !prefs.containsKey('app_first_launch');
      if (firstLaunch) {
        await prefs.setBool('app_first_launch', true);
      }
      
      // Check if onboarding is completed
      final onboardingCompleted = prefs.getBool('onboarding_completed') ?? false;
      
      // Show onboarding if it's the first launch AND not completed
      final shouldShow = firstLaunch && !onboardingCompleted;
      
      debugPrint('Should show onboarding: $shouldShow (firstLaunch: $firstLaunch, completed: $onboardingCompleted)');
      return shouldShow;
    } catch (e) {
      debugPrint('Error checking onboarding: $e');
      return true; // Show onboarding by default if error
    }
  }

  Future<void> _completeOnboarding() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool('onboarding_completed', true);
      debugPrint('Onboarding completed');
    } catch (e) {
      debugPrint('Error completing onboarding: $e');
    }
  }

  void _handlePasswordResetLink() {
    // Attendre que Supabase soit initialisé
    try {
      Supabase.instance.client.auth.onAuthStateChange.listen((data) {
        final AuthChangeEvent event = data.event;
        
        if (event == AuthChangeEvent.passwordRecovery) {
          // L'utilisateur a cliqué sur le lien de réinitialisation
          Navigator.of(context).pushNamedAndRemoveUntil(
            '/reset-password',
            (route) => false,
          );
        }
      });
    } catch (e) {
      debugPrint('Supabase not yet initialized: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    if (!_isInitialized) {
      return const Scaffold(
        body: Center(
          child: CircularProgressIndicator(),
        ),
      );
    }

    return _showOnboarding ? const PageOnboarding() : const PageConnexion();
  }
}
